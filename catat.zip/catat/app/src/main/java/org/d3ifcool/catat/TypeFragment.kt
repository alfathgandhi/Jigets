package org.d3ifcool.catat

import android.app.Application
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.widget.Toolbar
import androidx.appcompat.app.ActionBar
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.fragment_type.*

class TypeFragment:Fragment(),RecycleListClickListener{
    override fun ItemClicked(position: Int, id: String?) {

    }

    private lateinit var databaseReference: DatabaseReference
    private lateinit var view_fragment:View
    val instace = FirebaseAuth.getInstance()
    private lateinit var gridLayoutManager:GridLayoutManager
   private lateinit var typeAdapter: TypeAdapter
   private var rv: RecyclerView ?= null
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        view_fragment = inflater.inflate(R.layout.fragment_type,container,false)


        rv = view_fragment.findViewById(R.id.rvQuiz)
        gridLayoutManager = GridLayoutManager(context,2, LinearLayoutManager.VERTICAL,false)

         rv?.setLayoutManager(gridLayoutManager)

        rv?.setHasFixedSize(true)

        val array = arrayListOf<Type>()


        val adapter = TypeAdapter(this)
        communicator = activity as Communicator

        databaseReference = FirebaseDatabase.getInstance().reference.child("Type")

        databaseReference.addValueEventListener(object  : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                    array.clear()

                for (data in snapshot.children){
                    array.add(data.getValue(Type::class.java)!!)

                    }
                adapter.data = array

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })




        rv?.adapter = adapter

//        activity.SupportActionBar()!!.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM)
//        getSupportActionBar()!!.setCustomView(R.layout.actionbar)
//


        return view_fragment

    }
private lateinit var communicator: Communicator
    override fun onClicked(position: Int, part: Part?, type: Type?) {

        communicator.sendString(type?.nama!!)



    }
}