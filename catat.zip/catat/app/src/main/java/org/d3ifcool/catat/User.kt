package org.d3ifcool.catat

class User {
    var nama : String?= null
    var nrp : String?= null
    var seksi : String?= null
    var noHp : String?= null
    var username : String?= null


    constructor(){}

    constructor(nama:String?,nrp:String?,seksi:String?,noHp:String?,username:String?)
    {
        this.nama = nama
        this.nrp = nrp
        this.seksi = seksi
        this.noHp = noHp
        this.username = username





    }





}